var express = require('express');
var Sequelize = require ('sequelize');
var bodyParser = require ('body-parser');
var router = express.Router();

var app = express();

/**var  connection = new Sequelize('Qpje', 'root', '');

var Pergunta = connection.define('pergunta', {
  name: Sequelize.STRING,
  email: Sequelize.STRING,
  question: Sequelize.TEXT
});

connection.sync().then(function(){
  Pergunta.create({
    name: 'pablo',
    email: 'pablolima@gmail.com',
    question: 'como se faz?'
  });
});
*/

app.use(express.static(__dirname + '/public'));
app.use(bodyParser());


var perguntas = [
			{nome: "Pablo", email: "pablolm4@gmail.com", pergunta:"Alguma coisa... " },
			{nome: "Victor Magão", email: "saidafrente@hotmail.com", pergunta:"olá, tudo bom ?"  }
			];


router.get('/perguntas', function(req, res) {
  res.json(perguntas);
});

router.post('/perguntas', function(req, res) {
  perguntas.push(req.body);
  res.json(true);
});

router.get('/', function(req, res){
	res.send('im the home page!');
});


app.listen(1337, function(){

	console.log('ready on http://127.0.0.1:1337');
}); 

app.use('/', router);                             